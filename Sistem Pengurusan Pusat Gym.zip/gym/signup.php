<html>
<body bgcolor="white">
<head>
	<title>Daftar Ahli Baru!!!</title> <!--koding untuk heading html-->
</head>
<style type="text/css">
	
</style>
<body>
<center>
	<br>
	<br>
	<br>
	<br><h1>Daftar ahli baru</h1>
<form action="pros_login.php" method="post">
	<table>
		<tr>
			<th>username:
				<input type="text" name="username">
			</th>
		</tr>
		<tr>
			<th>password:
				<input type="password" name="password">	
			</th>
		</tr>
	</table>
	
	<button type="submit"value="submit">Hantar</button> <!--koding butang hantar-->
	<input type="reset" name="reset"><!--koding butang reset-->
	
</form>
</center>
