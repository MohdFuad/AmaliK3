<!DOCTYPE html>
<html>
<style>

body{
  background-color:lightblue;  
}  /*kod pengaturcaraan yang digunakan untuk 
    warna latar belakang*/

</style>
<body bgcolor="cyan">
<center>
<form id="form" name="form" method="post" action="pros_insert.php">
<table width="400" border="1">
<tr>
<th scope="col">Bilangan Treadmill:</th>
<th scope="col"><div align="left">
<input type="text" name="bil_katil" value="" size="50"/> /*input bilangan treadmill*/
<div>
</th>
</tr>
<tr>
<th scope="col">Bilangan Dumbell:</th>
<th scope="col"><div align="left">
<input type="text" name="bil_katil" value="" size="50"/>  /*input
bilangan dumbell*/
<div>
</th>
</tr>

<tr>
<th scope="col">Bilangan Bola Yoga:</th>
<th scope="col"><div align="left">
<input type="text" name="bil_locker" value="" size="50"/>
<div>
</th> 
</tr>
<tr>
<th scope="col">Catatan</th> 
<th scope="col"><div align="left">
<input type="text" name="catatan" value="" size="50"/> 
<div>
</th>
</tr>
    
  </table>
  <br>
<center><button type="submit"value="submit">Hantar</button>
</br>
</form>
</br>
</br>
</center>
</body>
</html>
